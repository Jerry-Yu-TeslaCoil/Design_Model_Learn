package cn.cupk.patterns.main.java.logger;

public class JsonLogger implements Logger {
    @Override
    public int writeLog(String msg) {
        //TODO: Write msg into Json File
        System.out.println("Json Log: " + msg);
        return 0;
    }
}
