/**
 *
 */
package cn.cupk.patterns.main.java.logger;

/**
 *
 */
public class DatabaseLogger implements Logger {
    @Override
    public int writeLog(String msg) {
        //TODO: Write msg into Database
        System.out.println("DB Log: " + msg);
        return 0;
    }
}
