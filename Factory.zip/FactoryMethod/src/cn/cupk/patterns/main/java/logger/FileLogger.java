/**
 *
 */
package cn.cupk.patterns.main.java.logger;

/**
 *
 */
public class FileLogger implements Logger {
    @Override
    public int writeLog(String msg) {
        //TODO: Write msg into log File
        System.out.println("File Log: " + msg);
        return 0;
    }
}
