/**
 *
 */
package cn.cupk.patterns.main.java.loggerfactory;

import cn.cupk.patterns.main.java.logger.Logger;

/**
 *
 */
public abstract class LoggerFactory {

    public int writeLog(String msg) {
        createLogger().writeLog(msg);
        return 0;
    }

    public abstract Logger createLogger();
}
