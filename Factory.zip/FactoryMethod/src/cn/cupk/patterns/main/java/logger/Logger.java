/**
 *
 */
package cn.cupk.patterns.main.java.logger;

/**
 *
 */
public interface Logger {

    int writeLog(String msg);
}
