package cn.cupk.patterns.main.java.util;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class XMLUtil {

    public static String getXMLString(String url, String tag) throws ParserConfigurationException,
            IOException, SAXException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db =dbf.newDocumentBuilder();
        Document doc = db.parse(url);

        NodeList nodeList = doc.getElementsByTagName(tag);
        Node infoTypeNode = nodeList.item(0).getFirstChild();
        return infoTypeNode.getNodeValue().trim();
    }

    public static Object getBean(String url, String tag) throws ParserConfigurationException,
            IOException, SAXException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException,
            InstantiationException, IllegalAccessException {
        String className = XMLUtil.getXMLString(url, tag);
        return Class.forName(className).getDeclaredConstructor().newInstance();
    }
}
