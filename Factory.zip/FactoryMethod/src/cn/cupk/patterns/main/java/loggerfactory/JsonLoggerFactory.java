package cn.cupk.patterns.main.java.loggerfactory;

import cn.cupk.patterns.main.java.logger.JsonLogger;
import cn.cupk.patterns.main.java.logger.Logger;

public class JsonLoggerFactory extends LoggerFactory {
    @Override
    public Logger createLogger() {
        return new JsonLogger();
    }
}
