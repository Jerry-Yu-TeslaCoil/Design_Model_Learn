/**
 *
 */
package cn.cupk.patterns.main.java.loggerfactory;

import cn.cupk.patterns.main.java.logger.FileLogger;
import cn.cupk.patterns.main.java.logger.Logger;

/**
 *
 */
public class FileLoggerFactory extends LoggerFactory {

    @Override
    public Logger createLogger() {
        return new FileLogger();
    }
}
