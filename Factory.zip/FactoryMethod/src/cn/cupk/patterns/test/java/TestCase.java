package cn.cupk.patterns.test.java;

import cn.cupk.patterns.main.java.loggerfactory.LoggerFactory;
import cn.cupk.patterns.main.java.util.XMLUtil;
import org.junit.Test;
import cn.cupk.patterns.main.java.logger.Logger;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class TestCase {

    @Test
    public void testRun() throws ParserConfigurationException, IOException, SAXException, ClassNotFoundException,
            NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {

        Logger log;

        LoggerFactory factory;

        factory = (LoggerFactory)XMLUtil.getBean("src/cn/cupk/patterns/main/resource/config.xml", "className");

        factory.writeLog("Test");
    }
}
