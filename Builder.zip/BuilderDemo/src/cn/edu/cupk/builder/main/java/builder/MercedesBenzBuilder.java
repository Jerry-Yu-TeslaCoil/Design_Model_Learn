package cn.edu.cupk.builder.main.java.builder;

public class MercedesBenzBuilder extends CarBuilder {
    @Override
    public void buildBrand() {
        super.car.setBrand("Mercedes_Benz");
    }

    @Override
    public void buildEngine() {
        super.car.setEngine("2.0T");
    }

    @Override
    public void buildGearbox() {
        super.car.setGearbox("CVT");
    }

    @Override
    public void buildTires() {
        super.car.setTires("Continental");
    }
}
