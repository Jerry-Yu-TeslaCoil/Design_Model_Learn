package cn.edu.cupk.builder.main.java.builder;

public class BMWCarBuilder extends CarBuilder {
    @Override
    public void buildBrand() {
        super.car.setBrand("BMW");
    }

    @Override
    public void buildEngine() {
        super.car.setEngine("3.0T");
    }

    @Override
    public void buildGearbox() {
        super.car.setGearbox("9AT");
    }

    @Override
    public void buildTires() {
        super.car.setTires("Michelin");
    }
}
