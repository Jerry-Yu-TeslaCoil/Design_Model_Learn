package cn.edu.cupk.builder.main.java.builder;

import cn.edu.cupk.builder.main.java.CarProduct;

public abstract class CarBuilder {

    protected CarProduct car = new CarProduct();

    public CarProduct getCar() {
        return car;
    }

    public abstract void buildBrand();
    public abstract void buildEngine();
    public abstract void buildGearbox();
    public abstract void buildTires();
}
