package cn.edu.cupk.builder.main.java;

public class CarProduct {

    private String brand;
    private String tires;
    private String engine;
    private String gearbox;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getTires() {
        return tires;
    }

    public void setTires(String tires) {
        this.tires = tires;
    }

    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public String getGearbox() {
        return gearbox;
    }

    public void setGearbox(String gearbox) {
        this.gearbox = gearbox;
    }

    @Override
    public String toString() {
        return "CarProduct{" +
                "brand='" + brand + '\'' +
                ", tires='" + tires + '\'' +
                ", engine='" + engine + '\'' +
                ", gearbox='" + gearbox + '\'' +
                '}';
    }
}
