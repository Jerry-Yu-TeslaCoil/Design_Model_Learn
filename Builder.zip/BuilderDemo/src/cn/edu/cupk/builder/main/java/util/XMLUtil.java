package cn.edu.cupk.builder.main.java.util;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class XMLUtil {
    public static Object getBean() throws ParserConfigurationException, IOException, SAXException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File("src/cn/edu/cupk/builder/main/resource/config.xml"));

        NodeList nl = doc.getElementsByTagName("carbuilder");
        Node carbuilder = nl.item(0).getFirstChild();
        String builderName = carbuilder.getNodeValue().trim();
        return Class.forName(builderName).getDeclaredConstructor().newInstance();
    }
}
