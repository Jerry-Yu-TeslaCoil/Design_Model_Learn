package cn.edu.cupk.builder.main.java;

import cn.edu.cupk.builder.main.java.builder.CarBuilder;
import cn.edu.cupk.builder.main.java.util.XMLUtil;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) throws ParserConfigurationException, IOException,
            ClassNotFoundException, InvocationTargetException, SAXException, NoSuchMethodException,
            InstantiationException, IllegalAccessException {
        System.out.println("Builder Demo");

        CarBuilder carBuilder = (CarBuilder) XMLUtil.getBean();

        CarBuilderDirector carBuilderDirector = new CarBuilderDirector(carBuilder);

        CarProduct carProduct = carBuilderDirector.buildCarProduct();

        System.out.println(carProduct);

    }
}