package cn.edu.cupk.builder.main.java;

import cn.edu.cupk.builder.main.java.builder.CarBuilder;

public class CarBuilderDirector {
    private CarBuilder carBuilder;

    public CarBuilderDirector(CarBuilder carBuilder) {
        this.carBuilder = carBuilder;
    }

    public void setCarBuilder(CarBuilder carBuilder) {
        this.carBuilder = carBuilder;
    }

    public CarProduct buildCarProduct() {
        carBuilder.buildBrand();
        carBuilder.buildEngine();
        carBuilder.buildGearbox();
        carBuilder.buildTires();
        return carBuilder.getCar();
    }
}
