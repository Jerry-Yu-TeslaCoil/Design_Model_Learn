package cn.cupk.factory.main.java.factory;

import cn.cupk.factory.main.java.product.ComboBox.ComboBox;
import cn.cupk.factory.main.java.product.button.Button;
import cn.cupk.factory.main.java.product.textbox.TextBox;

public interface SkinFactory {
    public Button createButton();
    public ComboBox createComboBox();
    public TextBox createTextBox();
}
