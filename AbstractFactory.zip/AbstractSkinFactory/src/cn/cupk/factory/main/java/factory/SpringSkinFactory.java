package cn.cupk.factory.main.java.factory;

import cn.cupk.factory.main.java.product.ComboBox.ComboBox;
import cn.cupk.factory.main.java.product.ComboBox.SpringComboBox;
import cn.cupk.factory.main.java.product.button.Button;
import cn.cupk.factory.main.java.product.button.SpringButton;
import cn.cupk.factory.main.java.product.textbox.SpringTextBox;
import cn.cupk.factory.main.java.product.textbox.TextBox;

public class SpringSkinFactory implements SkinFactory {
    @Override
    public Button createButton() {
        return new SpringButton();
    }

    @Override
    public ComboBox createComboBox() {
        return new SpringComboBox();
    }

    @Override
    public TextBox createTextBox() {
        return new SpringTextBox();
    }
}
