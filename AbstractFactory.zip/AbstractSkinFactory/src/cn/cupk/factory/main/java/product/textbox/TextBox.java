package cn.cupk.factory.main.java.product.textbox;

public abstract class TextBox {
    public String text;
}
