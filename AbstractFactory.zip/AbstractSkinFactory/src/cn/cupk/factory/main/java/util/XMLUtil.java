package cn.cupk.factory.main.java.util;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class XMLUtil {

    public static String XMLParser(String url, String tag) throws ParserConfigurationException,
            IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(url);

        NodeList nodeList = document.getElementsByTagName(tag);
        Node node = nodeList.item(0).getFirstChild();
        return node.getNodeValue().trim();
    }

    public static Object getBean(String url, String tag) throws ParserConfigurationException,
            IOException, SAXException, ClassNotFoundException, NoSuchMethodException,
            InvocationTargetException, InstantiationException, IllegalAccessException {
        String className = XMLParser(url, tag);
        return Class.forName(className).getDeclaredConstructor().newInstance();
    }
}
