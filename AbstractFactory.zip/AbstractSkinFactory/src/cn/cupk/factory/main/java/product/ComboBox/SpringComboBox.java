package cn.cupk.factory.main.java.product.ComboBox;

public class SpringComboBox extends ComboBox {
    public SpringComboBox() {
        this("");
    }

    public SpringComboBox(String label) {
        super.label = "LightGreen " + label;
    }
}
