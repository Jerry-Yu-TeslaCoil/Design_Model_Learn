package cn.cupk.factory.main.java.product.textbox;

public class SummerTextBox extends TextBox {
    public SummerTextBox() {
        this("");
    }

    public SummerTextBox(String label) {
        super.text = "Orange " + label;
    }
}
