package cn.cupk.factory.main.java.product.button;

public class SummerButton extends Button {

    public SummerButton() {
        this("");
    }

    public SummerButton(String label) {
        super.label = "Orange " + label;
    }
}
