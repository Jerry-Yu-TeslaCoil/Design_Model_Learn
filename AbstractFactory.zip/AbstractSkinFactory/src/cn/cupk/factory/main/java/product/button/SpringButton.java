package cn.cupk.factory.main.java.product.button;

public class SpringButton extends Button {

    public SpringButton() {
        this("");
    }

    public SpringButton(String label) {
        super.label = "LightGreen " + label;
    }
}
