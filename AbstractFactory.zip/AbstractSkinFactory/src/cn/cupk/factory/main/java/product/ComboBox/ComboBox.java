package cn.cupk.factory.main.java.product.ComboBox;

public abstract class ComboBox {
    public String label;
}
