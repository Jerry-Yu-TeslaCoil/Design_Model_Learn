package cn.cupk.factory.main.java;

import cn.cupk.factory.main.java.factory.SkinFactory;
import cn.cupk.factory.main.java.product.ComboBox.ComboBox;
import cn.cupk.factory.main.java.product.button.Button;
import cn.cupk.factory.main.java.product.textbox.TextBox;
import cn.cupk.factory.main.java.util.XMLUtil;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) throws ParserConfigurationException, IOException,
            ClassNotFoundException, InvocationTargetException, SAXException, NoSuchMethodException,
            InstantiationException, IllegalAccessException {
        SkinFactory skinFactory = (SkinFactory) XMLUtil
                .getBean("src/cn/cupk/factory/main/resource/config.xml", "skin");
        Button button = skinFactory.createButton();
        ComboBox comboBox = skinFactory.createComboBox();
        TextBox textBox = skinFactory.createTextBox();
        System.out.println(button.label);
        System.out.println(comboBox.label);
        System.out.println(textBox.text);
    }
}