package cn.cupk.factory.main.java.product.ComboBox;

public class SummerComboBox extends ComboBox {
    public SummerComboBox() {
        this("");
    }

    public SummerComboBox(String label) {
        super.label = "Orange " + label;
    }
}
