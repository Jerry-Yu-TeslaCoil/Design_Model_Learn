package cn.cupk.factory.main.java.product.textbox;

public class SpringTextBox extends TextBox {
    public SpringTextBox() {
        this("");
    }

    public SpringTextBox(String label) {
        super.text = "LightGreen " + label;
    }
}
