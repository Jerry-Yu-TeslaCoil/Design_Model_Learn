package cn.cupk.factory.main.java.product.button;

public abstract class Button {
    public String label;
}
