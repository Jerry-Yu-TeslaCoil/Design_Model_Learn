package cn.cupk.factory.main.java.factory;

import cn.cupk.factory.main.java.product.ComboBox.ComboBox;
import cn.cupk.factory.main.java.product.ComboBox.SummerComboBox;
import cn.cupk.factory.main.java.product.button.Button;
import cn.cupk.factory.main.java.product.button.SummerButton;
import cn.cupk.factory.main.java.product.textbox.SummerTextBox;
import cn.cupk.factory.main.java.product.textbox.TextBox;

public class SummerSkinFactory implements SkinFactory {
    @Override
    public Button createButton() {
        return new SummerButton();
    }

    @Override
    public ComboBox createComboBox() {
        return new SummerComboBox();
    }

    @Override
    public TextBox createTextBox() {
        return new SummerTextBox();
    }
}
